#!/bin/sh

set -eu
umask 077

ENDPOINT='https://cpa2.zsxssl.top:9443/v1'
BLOCK_START='<!-- CODEX_QUICK_SETUP_IMAGE_GENERATION_BEGIN -->'
BLOCK_END='<!-- CODEX_QUICK_SETUP_IMAGE_GENERATION_END -->'
LEGACY_BLOCK_START='<!-- CPA_QUICK_SETUP_IMAGE_GENERATION_BEGIN -->'
LEGACY_BLOCK_END='<!-- CPA_QUICK_SETUP_IMAGE_GENERATION_END -->'

usage() {
    cat <<'EOF'
用法：
  ./codex-quick-setup.sh install   写入一键配置
  ./codex-quick-setup.sh restore   恢复官方账号登录
EOF
}

die() {
    printf '错误：%s\n' "$*" >&2
    exit 1
}

codex_home=${CODEX_HOME:-"$HOME/.codex"}
config_path="$codex_home/config.toml"
auth_path="$codex_home/auth.json"
agents_path="$codex_home/AGENTS.md"

make_temp() {
    mktemp "$codex_home/.codex-quick-setup.XXXXXX"
}

backup_files() {
    if [ ! -f "$config_path" ] && [ ! -f "$auth_path" ] && [ ! -f "$agents_path" ]; then
        backup_dir=''
        return
    fi

    stamp=$(date '+%Y%m%d-%H%M%S')
    backup_dir="$codex_home/.codex-quick-setup-backups/$stamp-$$"
    mkdir -p "$backup_dir"
    [ ! -f "$config_path" ] || cp -p "$config_path" "$backup_dir/config.toml"
    [ ! -f "$auth_path" ] || cp -p "$auth_path" "$backup_dir/auth.json"
    [ ! -f "$agents_path" ] || cp -p "$agents_path" "$backup_dir/AGENTS.md"
}

logout_codex() {
    if [ "${CODEX_QUICK_SETUP_SKIP_LOGOUT:-0}" = '1' ]; then
        return
    fi
    if command -v codex >/dev/null 2>&1; then
        if ! codex logout >/dev/null 2>&1; then
            printf '提示：codex logout 未成功；仍将继续处理本地配置。\n' >&2
        fi
    else
        printf '提示：未找到 codex 命令，无法自动清除钥匙串中的旧 Codex 凭据。\n' >&2
    fi
}

filter_config() {
    source_file=$1
    mode=$2
    awk '
        function is_managed_root(line) {
            return line ~ /^[[:space:]]*(model_provider|model|cli_auth_credentials_store|disable_response_storage|model_context_window|model_auto_compact_token_limit|model_auto_compact_token_limit_scope)[[:space:]]*=/
        }
        BEGIN { in_root = 1; skip_custom = 0 }
        {
            trimmed = $0
            sub(/^[[:space:]]*/, "", trimmed)
            sub(/[[:space:]]*$/, "", trimmed)

            if (skip_custom) {
                if (trimmed ~ /^\[.*\]$/) {
                    skip_custom = 0
                } else {
                    next
                }
            }

            if (tolower(trimmed) == "[model_providers.custom]") {
                skip_custom = 1
                in_root = 0
                next
            }
            if (trimmed ~ /^\[.*\]$/) {
                in_root = 0
            }
            if (in_root && is_managed_root($0)) {
                next
            }
            print
        }
    ' "$source_file"
}

write_install_config() {
    source=$config_path
    if [ ! -f "$source" ]; then
        source=/dev/null
    fi
    filtered=$(make_temp)
    target=$(make_temp)
    filter_config "$source" install > "$filtered"

    cat > "$target" <<EOF
model_provider = "custom"
model = "gpt-6.1-sol"
cli_auth_credentials_store = "file"
disable_response_storage = true
model_context_window = 270000
model_auto_compact_token_limit = 250000
model_auto_compact_token_limit_scope = "body_after_prefix"
EOF
    if [ -s "$filtered" ]; then
        printf '\n' >> "$target"
        cat "$filtered" >> "$target"
    fi
    cat >> "$target" <<EOF

[model_providers.custom]
name = "OpenAI Compatible"
wire_api = "responses"
requires_openai_auth = true
base_url = "$ENDPOINT"
supports_websockets = true
EOF
    mv -f "$target" "$config_path"
    rm -f "$filtered"
}

write_restore_config() {
    [ -f "$config_path" ] || return
    target=$(make_temp)
    filter_config "$config_path" restore > "$target"
    if grep -q '[^[:space:]]' "$target"; then
        mv -f "$target" "$config_path"
    else
        rm -f "$target" "$config_path"
    fi
}

remove_managed_agents_blocks() {
    source_file=$1
    target_file=$2
    awk -v start="$BLOCK_START" -v end="$BLOCK_END" \
        -v legacy_start="$LEGACY_BLOCK_START" -v legacy_end="$LEGACY_BLOCK_END" '
        $0 == start || $0 == legacy_start { skip = 1; next }
        $0 == end || $0 == legacy_end { skip = 0; next }
        !skip { print }
    ' "$source_file" > "$target_file"
}

write_install_agents() {
    source=$agents_path
    if [ ! -f "$source" ]; then
        source=/dev/null
    fi
    filtered=$(make_temp)
    target=$(make_temp)
    remove_managed_agents_blocks "$source" "$filtered"
    cat "$filtered" > "$target"
    if [ -s "$target" ]; then
        printf '\n' >> "$target"
    fi
    cat >> "$target" <<'EOF'
<!-- CODEX_QUICK_SETUP_IMAGE_GENERATION_BEGIN -->
## 图片生成兼容规则

当用户请求“生成图片”“画一张图”或同义任务，而当前会话没有可用的内置图片生成工具时：

1. 从 `~/.codex/auth.json` 读取 `OPENAI_API_KEY`；不得把 Key 输出到日志、终端回显或回复中。
2. 从 `~/.codex/config.toml` 读取当前 `model_provider` 对应的 `base_url`。
3. 调用标准 OpenAI 兼容图片接口：`POST {base_url}/images/generations`，使用 Bearer Key；请求模型使用 `gpt-image-1`，并根据用户要求传入 prompt、尺寸等参数。
4. 支持响应中的 `b64_json` 或 URL：将图片保存到当前项目的 `generated-images/` 目录。
5. 在 Codex 回复中用绝对本地路径直接展示生成结果，并简要说明保存位置。
6. 如果接口返回明确错误，原样概括错误原因并给出可执行的修复建议；不要伪造图片结果。

如果当前会话已有可用的内置图片生成工具，优先使用内置工具。
<!-- CODEX_QUICK_SETUP_IMAGE_GENERATION_END -->
EOF
    mv -f "$target" "$agents_path"
    rm -f "$filtered"
}

write_restore_agents() {
    [ -f "$agents_path" ] || return
    target=$(make_temp)
    remove_managed_agents_blocks "$agents_path" "$target"
    if grep -q '[^[:space:]]' "$target"; then
        mv -f "$target" "$agents_path"
    else
        rm -f "$target" "$agents_path"
    fi
}

read_key() {
    if [ -n "${CODEX_QUICK_SETUP_KEY:-}" ]; then
        api_key=$CODEX_QUICK_SETUP_KEY
    else
        printf '请输入服务器生成的完整 API Key：' >&2
        if [ -t 0 ]; then
            stty -echo
            IFS= read -r api_key || {
                stty echo
                printf '\n' >&2
                die '未能读取 API Key。'
            }
            stty echo
            printf '\n' >&2
        else
            IFS= read -r api_key || die '未能读取 API Key。'
        fi
    fi
    [ "${#api_key}" -ge 12 ] || die 'API Key 太短。'
    [ "${#api_key}" -le 1024 ] || die 'API Key 长度异常。'
    case "$api_key" in
        *[!abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._~+/=-]*)
            die 'API Key 含空格、控制字符或不支持的特殊字符。'
            ;;
    esac
}

write_auth() {
    escaped=$(printf '%s' "$api_key" | sed 's/\\/\\\\/g; s/"/\\"/g')
    target=$(make_temp)
    printf '{"OPENAI_API_KEY":"%s"}\n' "$escaped" > "$target"
    chmod 600 "$target"
    mv -f "$target" "$auth_path"
}

install_config() {
    read_key
    mkdir -p "$codex_home"
    backup_files
    logout_codex
    write_install_config
    write_auth
    write_install_agents
    printf '\n配置已写入：%s\n' "$codex_home"
    [ -z "$backup_dir" ] || printf '原文件已备份到：%s\n' "$backup_dir"
    printf '请按 Command + Q 完全退出 ChatGPT/Codex，然后重新打开。\n'
}

restore_login() {
    mkdir -p "$codex_home"
    backup_files
    logout_codex
    write_restore_config
    rm -f "$auth_path"
    write_restore_agents
    printf '\n已恢复官方登录配置。\n'
    [ -z "$backup_dir" ] || printf '原文件已备份到：%s\n' "$backup_dir"
    printf '请按 Command + Q 完全退出 ChatGPT/Codex，重新打开后按提示登录官方账号。\n'
    if ! command -v codex >/dev/null 2>&1; then
        printf '若客户端仍自动使用旧登录，请在客户端内执行 Log out；只删除“钥匙串访问”中明确属于 Codex 的认证项。\n'
    fi
}

case "${1:-}" in
    install) install_config ;;
    restore) restore_login ;;
    -h|--help|help) usage ;;
    *) usage >&2; exit 2 ;;
esac

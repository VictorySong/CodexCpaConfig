#!/bin/sh

set -eu
umask 077

ENDPOINT='https://cpa2.zsxssl.top:9443/v1'
BLOCK_START='<!-- CODEX_QUICK_SETUP_IMAGE_GENERATION_BEGIN -->'
BLOCK_END='<!-- CODEX_QUICK_SETUP_IMAGE_GENERATION_END -->'
LEGACY_BLOCK_START='<!-- CPA_QUICK_SETUP_IMAGE_GENERATION_BEGIN -->'
LEGACY_BLOCK_END='<!-- CPA_QUICK_SETUP_IMAGE_GENERATION_END -->'

usage() {
    cat <<'EOF'
用法：
  ./codex-quick-setup.sh install   写入一键配置
  ./codex-quick-setup.sh restore   恢复官方账号登录
  ./codex-quick-setup.sh proxy-on      开启访问代理
  ./codex-quick-setup.sh proxy-off     关闭访问代理并恢复原设置
  ./codex-quick-setup.sh proxy-status  查看访问代理状态
EOF
}

die() {
    printf '错误：%s\n' "$*" >&2
    exit 1
}

homes_file=$(mktemp "${TMPDIR:-/tmp}/codex-quick-setup-homes.XXXXXX")
trap 'rm -f "$homes_file"' EXIT HUP INT TERM

add_home() {
    candidate=$1
    [ -n "$candidate" ] || return 0
    case "$candidate" in
        '~') candidate=$HOME ;;
        '~/'*) candidate=$HOME/${candidate#~/} ;;
    esac
    candidate=${candidate%/}
    [ -n "$candidate" ] || candidate=/
    if ! grep -Fqx "$candidate" "$homes_file" 2>/dev/null; then
        printf '%s\n' "$candidate" >> "$homes_file"
    fi
}

discover_homes() {
    : > "$homes_file"
    add_home "${CODEX_HOME:-}"
    add_home "$HOME/.codex"
    settings=$HOME/.cc-switch/settings.json
    if [ -f "$settings" ]; then
        configured=$(sed -nE 's/.*"codex_config_dir"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/p' "$settings" | head -n 1)
        if [ -z "$configured" ]; then
            configured=$(sed -nE 's/.*"codexConfigDir"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/p' "$settings" | head -n 1)
        fi
        [ -z "$configured" ] || add_home "$configured"
    fi
}

set_paths() {
    codex_home=$1
    config_path=$codex_home/config.toml
    auth_path=$codex_home/auth.json
    agents_path=$codex_home/AGENTS.md
}

make_temp() {
    mktemp "$codex_home/.codex-quick-setup.XXXXXX"
}

backup_files() {
    if [ ! -f "$config_path" ] && [ ! -f "$auth_path" ] && [ ! -f "$agents_path" ]; then
        backup_dir=''
        return
    fi
    stamp=$(date '+%Y%m%d-%H%M%S')
    backup_dir=$codex_home/.codex-quick-setup-backups/$stamp-$$
    mkdir -p "$backup_dir"
    [ ! -f "$config_path" ] || cp -p "$config_path" "$backup_dir/config.toml"
    [ ! -f "$auth_path" ] || cp -p "$auth_path" "$backup_dir/auth.json"
    [ ! -f "$agents_path" ] || cp -p "$agents_path" "$backup_dir/AGENTS.md"
}

logout_codex() {
    if [ "${CODEX_QUICK_SETUP_SKIP_LOGOUT:-0}" = '1' ]; then
        return 0
    fi
    if command -v codex >/dev/null 2>&1; then
        codex logout >/dev/null 2>&1 || printf '提示：codex logout 未成功；仍将继续处理本地配置。\n' >&2
    else
        printf '提示：未找到 codex 命令，无法自动清除钥匙串中的旧 Codex 凭据。\n' >&2
    fi
}

filter_config() {
    source_file=$1
    awk '
        function is_managed_root(line) {
            return line ~ /^[[:space:]]*(model_provider|model|cli_auth_credentials_store|disable_response_storage|model_context_window|model_auto_compact_token_limit|model_auto_compact_token_limit_scope)[[:space:]]*=/
        }
        BEGIN { in_root = 1; skip_custom = 0 }
        {
            trimmed = $0
            sub(/^[[:space:]]*/, "", trimmed)
            sub(/[[:space:]]*$/, "", trimmed)
            if (skip_custom) {
                if (trimmed ~ /^\[.*\]$/) skip_custom = 0
                else next
            }
            if (tolower(trimmed) == "[model_providers.custom]") {
                skip_custom = 1
                in_root = 0
                next
            }
            if (trimmed ~ /^\[.*\]$/) in_root = 0
            if (in_root && is_managed_root($0)) next
            print
        }
    ' "$source_file"
}

ensure_desktop_reasoning_efforts() {
    reasoning_source_file=$1
    reasoning_target=$(make_temp)
    awk -v setting='enabled-reasoning-efforts = ["low", "medium", "high", "xhigh", "max", "ultra"]' '
        BEGIN { in_desktop = 0; saw_desktop = 0; wrote_setting = 0 }
        {
            trimmed = $0
            sub(/^[[:space:]]*/, "", trimmed)
            sub(/[[:space:]]*$/, "", trimmed)
            lowered = tolower(trimmed)
            if (trimmed ~ /^\[.*\]$/) {
                if (in_desktop && !wrote_setting) print setting
                in_desktop = (lowered == "[desktop]")
                if (in_desktop) {
                    saw_desktop = 1
                    wrote_setting = 0
                }
                print
                next
            }
            if (in_desktop && lowered ~ /^enabled-reasoning-efforts[[:space:]]*=/) {
                if (!wrote_setting) {
                    print setting
                    wrote_setting = 1
                }
                next
            }
            print
        }
        END {
            if (in_desktop && !wrote_setting) print setting
            if (!saw_desktop) {
                print ""
                print "[desktop]"
                print setting
            }
        }
    ' "$reasoning_source_file" > "$reasoning_target"
    mv -f "$reasoning_target" "$reasoning_source_file"
}

write_install_config() {
    source=$config_path
    [ -f "$source" ] || source=/dev/null
    filtered=$(make_temp)
    target=$(make_temp)
    filter_config "$source" > "$filtered"
    cat > "$target" <<EOF
model_provider = "custom"
model = "gpt-6.1-sol"
cli_auth_credentials_store = "file"
model_context_window = 270000
model_auto_compact_token_limit = 250000
model_auto_compact_token_limit_scope = "body_after_prefix"
EOF
    if [ -s "$filtered" ]; then
        printf '\n' >> "$target"
        cat "$filtered" >> "$target"
    fi
    cat >> "$target" <<EOF

[model_providers.custom]
name = "OpenAI Compatible"
wire_api = "responses"
requires_openai_auth = true
base_url = "$ENDPOINT"
experimental_bearer_token = "$api_key"
supports_websockets = true
EOF
    ensure_desktop_reasoning_efforts "$target"
    mv -f "$target" "$config_path"
    rm -f "$filtered"
}

write_restore_config() {
    [ -f "$config_path" ] || return
    target=$(make_temp)
    filter_config "$config_path" > "$target"
    if grep -q '[^[:space:]]' "$target"; then
        mv -f "$target" "$config_path"
    else
        rm -f "$target" "$config_path"
    fi
}

remove_managed_agents_blocks() {
    awk -v start="$BLOCK_START" -v end="$BLOCK_END" \
        -v legacy_start="$LEGACY_BLOCK_START" -v legacy_end="$LEGACY_BLOCK_END" '
        $0 == start || $0 == legacy_start { skip = 1; next }
        $0 == end || $0 == legacy_end { skip = 0; next }
        !skip { print }
    ' "$1" > "$2"
}

write_install_agents() {
    source=$agents_path
    [ -f "$source" ] || source=/dev/null
    filtered=$(make_temp)
    target=$(make_temp)
    remove_managed_agents_blocks "$source" "$filtered"
    cat "$filtered" > "$target"
    [ ! -s "$target" ] || printf '\n' >> "$target"
    cat >> "$target" <<'EOF'
<!-- CODEX_QUICK_SETUP_IMAGE_GENERATION_BEGIN -->
## 图片生成兼容规则

当用户请求“生成图片”“画一张图”或同义任务，而当前会话没有可用的内置图片生成工具时：

1. 先确定当前 Codex 配置目录：优先使用包含本 `AGENTS.md` 的目录；无法确定时使用环境变量 `CODEX_HOME`；仍无法确定时使用 `~/.codex`。
2. 从该目录的 `config.toml` 读取当前 `model_provider`，再从对应的 `[model_providers.<名称>]` 表读取 `base_url` 和 `experimental_bearer_token`；不得把 Token 输出到日志、终端回显或回复中。
3. 调用标准 OpenAI 兼容图片接口：`POST {base_url}/images/generations`，使用 `experimental_bearer_token` 作为 Bearer Token；请求模型使用 `gpt-image-1`，并根据用户要求传入 prompt、尺寸等参数。
4. 支持响应中的 `b64_json` 或 URL：将图片保存到当前项目的 `generated-images/` 目录。
5. 在 Codex 回复中用绝对本地路径直接展示生成结果，并简要说明保存位置。
6. 如果接口返回明确错误，原样概括错误原因并给出可执行的修复建议；不要伪造图片结果。

如果当前会话已有可用的内置图片生成工具，优先使用内置工具。
<!-- CODEX_QUICK_SETUP_IMAGE_GENERATION_END -->
EOF
    mv -f "$target" "$agents_path"
    rm -f "$filtered"
}

write_restore_agents() {
    [ -f "$agents_path" ] || return
    target=$(make_temp)
    remove_managed_agents_blocks "$agents_path" "$target"
    if grep -q '[^[:space:]]' "$target"; then
        mv -f "$target" "$agents_path"
    else
        rm -f "$target" "$agents_path"
    fi
}

read_key() {
    if [ -n "${CODEX_QUICK_SETUP_KEY:-}" ]; then
        api_key=$CODEX_QUICK_SETUP_KEY
    else
        printf '请输入服务器生成的完整 API Key：' >&2
        if [ -t 0 ]; then
            stty -echo
            IFS= read -r api_key || { stty echo; printf '\n' >&2; die '未能读取 API Key。'; }
            stty echo
            printf '\n' >&2
        else
            IFS= read -r api_key || die '未能读取 API Key。'
        fi
    fi
    [ "${#api_key}" -ge 12 ] || die 'API Key 太短。'
    [ "${#api_key}" -le 1024 ] || die 'API Key 长度异常。'
    case "$api_key" in
        *[!abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._~+/=-]*)
            die 'API Key 含空格、控制字符或不支持的特殊字符。'
            ;;
    esac
}

write_legacy_auth() {
    target=$(make_temp)
    printf '{"auth_mode":"apikey","OPENAI_API_KEY":"%s"}\n' "$api_key" > "$target"
    chmod 600 "$target"
    mv -f "$target" "$auth_path"
}

install_one() {
    set_paths "$1"
    mkdir -p "$codex_home"
    backup_files
    write_install_config
    write_legacy_auth
    write_install_agents
    printf '已配置：%s\n' "$codex_home"
    [ -z "$backup_dir" ] || printf '  备份：%s\n' "$backup_dir"
}

restore_one() {
    set_paths "$1"
    mkdir -p "$codex_home"
    backup_files
    write_restore_config
    rm -f "$auth_path"
    write_restore_agents
    printf '已恢复：%s\n' "$codex_home"
    [ -z "$backup_dir" ] || printf '  备份：%s\n' "$backup_dir"
}

install_config() {
    read_key
    discover_homes
    logout_codex
    while IFS= read -r home; do install_one "$home"; done < "$homes_file"
    printf '\nKey 已写入新式 Provider 和旧式纯 API-Key 文件；旧 OAuth 状态已清除。\n'
    printf '请按 Command + Q 完全退出 ChatGPT/Codex，然后重新打开。\n'
}

restore_login() {
    discover_homes
    logout_codex
    while IFS= read -r home; do restore_one "$home"; done < "$homes_file"
    printf '\n已恢复官方登录配置。\n'
    printf '请按 Command + Q 完全退出 ChatGPT/Codex，重新打开后按提示登录官方账号。\n'
    if ! command -v codex >/dev/null 2>&1; then
        printf '若客户端仍自动使用旧登录，请在客户端内执行 Log out；只删除“钥匙串访问”中明确属于 Codex 的认证项。\n'
    fi
}

proxy_warning() {
    red='\033[1;31m'
    reset='\033[0m'
    printf "${red}警告：公司电脑如果有监控程序慎用！${reset}\n" >&2
    printf '访问代理会在本机启动代理核心并临时接管 OpenAI/ChatGPT 官方域名。\n' >&2
    if [ "${CODEX_QUICK_SETUP_PROXY_CONFIRM:-}" = 'YES' ]; then
        return 0
    fi
    if command -v osascript >/dev/null 2>&1 && [ -t 0 ]; then
        if ! osascript -e 'display dialog "⚠️ 公司电脑如果有监控程序慎用！\n\n开启后会在本机运行访问代理，并临时修改自动代理设置。关闭代理时会恢复原设置。" buttons {"取消", "继续开启"} default button "取消" cancel button "取消" with title "访问代理安全提醒" with icon caution' >/dev/null 2>&1; then
            die '用户取消开启访问代理。'
        fi
        return 0
    fi
    printf '确认继续请输入 YES：' >&2
    IFS= read -r answer || die '未能读取确认。'
    [ "$answer" = 'YES' ] || die '用户取消开启访问代理。'
}

proxy_command() {
    action=$1
    helper=$(CDPATH= cd -- "$(dirname "$0")" && pwd)/codex-proxy.sh
    [ -f "$helper" ] || die '安装包中缺少代理控制脚本，请重新解压完整 ZIP。'
    chmod +x "$helper"
    case "$action" in
        on)
            proxy_warning
            read_key
            CODEX_QUICK_SETUP_KEY=$api_key "$helper" on
            ;;
        off) "$helper" off ;;
        status) "$helper" status ;;
    esac
}

case "${1:-}" in
    install) install_config ;;
    restore) restore_login ;;
    proxy-on) proxy_command on ;;
    proxy-off) proxy_command off ;;
    proxy-status) proxy_command status ;;
    -h|--help|help) usage ;;
    *) usage >&2; exit 2 ;;
esac

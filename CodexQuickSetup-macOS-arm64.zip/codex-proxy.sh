#!/bin/sh

set -eu
umask 077

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
APP_DIR="$HOME/Library/Application Support/CodexQuickSetup"
STATE_DIR="$APP_DIR/proxy-state"
RUNTIME_DIR="$APP_DIR/runtime"
XRAY_SOURCE="$SCRIPT_DIR/xray"
XRAY_BIN="$RUNTIME_DIR/xray"
XRAY_CONFIG="$RUNTIME_DIR/xray-client.json"
PLIST="$HOME/Library/LaunchAgents/top.zsxssl.codex-quick-proxy.plist"
LABEL='top.zsxssl.codex-quick-proxy'
LOCAL_PROXY_PORT=18781
API_ROOT='https://cpa.zsxssl.top:9443/quick-proxy'
TLS_PIN='sha256//t/waX26ic2Sn13/XYNFoQlnvll6yK7PG7+slmdn0O0M='
PUBLIC_KEY_FILE="$RUNTIME_DIR/server-signing-public.pem"

die() {
    printf '错误：%s\n' "$*" >&2
    exit 1
}

require_command() {
    command -v "$1" >/dev/null 2>&1 || die "系统缺少必要命令：$1"
}

json_string() {
    name=$1
    file=$2
    sed -nE 's/.*"'"$name"'"[[:space:]]*:[[:space:]]*"([^"\\]*)".*/\1/p' "$file" | head -n 1
}

json_number() {
    name=$1
    file=$2
    sed -nE 's/.*"'"$name"'"[[:space:]]*:[[:space:]]*([0-9]+).*/\1/p' "$file" | head -n 1
}

write_public_key() {
    mkdir -p "$RUNTIME_DIR"
    cat > "$PUBLIC_KEY_FILE" <<'EOF'
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAsDts1bntsrx0wCXfXypV
Bg1dZ/jHREUp9HVFdrp4BmzaXFx+q7r2UfrXMiU+Ib502VJ2jBHtb3u24yZExqCt
qkllFQKiL/3QM8YINHEVV76G0rZwLyKJDf9ehqVr7mqw3XumcUUYR0bwDMb45+01
/O4+X7Ro+opKI6pASg4Rvs5thAzzrIsuAQZjI6S95LTWKwhRFqb11CNLpdH62Mj9
igx+pZxqBJMXDgf0trNxKWz+KeN01LfoeGY5JwrMfzx1gfTmKaJg/UO/jNmISkhW
qU28VLNUM/5TNSs7MfWurtEbcfUwrHZnucHBY9Q4Kfju31s+s6l/7gEgxLkKlG5L
Rf1fjs9IS/BEomy63dS1avOqLuerCBC2oZwN5GRQNfWrpjLub22HOUeqnAqNEQrs
tD4ihdegcbY7h72EEHZIaQ9cDxTv3JV52FPhsaRx+Jlllen/PvCetbqNDTno1Fcc
jdylZKAU6IvQ6xAJqPN1ypFnvZCb3rTF+P6i2j7+lFptAgMBAAE=
-----END PUBLIC KEY-----
EOF
    chmod 600 "$PUBLIC_KEY_FILE"
}

verify_signature() {
    payload=$1
    signature=$2
    printf '%s' "$payload" > "$RUNTIME_DIR/signature-payload"
    printf '%s' "$signature" | openssl base64 -d -A > "$RUNTIME_DIR/signature.bin" 2>/dev/null || return 1
    openssl dgst -sha256 -verify "$PUBLIC_KEY_FILE" -signature "$RUNTIME_DIR/signature.bin" "$RUNTIME_DIR/signature-payload" >/dev/null 2>&1
}

request_endpoint() {
    api_key=${CODEX_QUICK_SETUP_KEY:-}
    [ -n "$api_key" ] || die '没有可用于代理校验的 API Key。'
    require_command curl
    require_command openssl
    require_command shasum
    write_public_key

    challenge_file="$RUNTIME_DIR/challenge.json"
    response_file="$RUNTIME_DIR/endpoint.json"
    curl --fail --silent --show-error --connect-timeout 10 --max-time 20 \
        --pinnedpubkey "$TLS_PIN" "$API_ROOT/api/challenge" > "$challenge_file" \
        || die '无法取得访问代理校验挑战。'
    nonce=$(json_string nonce "$challenge_file")
    expires_at=$(json_number expires_at "$challenge_file")
    challenge_signature=$(json_string signature "$challenge_file")
    [ -n "$nonce" ] && [ -n "$expires_at" ] && [ -n "$challenge_signature" ] \
        || die '服务端校验挑战格式不完整。'
    verify_signature "challenge
$nonce
$expires_at" "$challenge_signature" || die '服务端挑战签名无效，可能遭到网络拦截。'

    fingerprint=$(printf '%s' "$api_key" | shasum -a 256 | awk '{print $1}')
    proof_payload="proof
$fingerprint
$nonce
$expires_at"
    proof=$(printf '%s' "$proof_payload" | openssl dgst -sha256 -hmac "$api_key" -binary | openssl base64 -A)
    request_body=$(printf '{"fingerprint":"%s","nonce":"%s","expires_at":%s,"proof":"%s"}' \
        "$fingerprint" "$nonce" "$expires_at" "$proof")
    status=$(curl --silent --show-error --connect-timeout 10 --max-time 20 \
        --pinnedpubkey "$TLS_PIN" -o "$response_file" -w '%{http_code}' \
        -H 'Content-Type: application/json' --data-binary "$request_body" "$API_ROOT/api/resolve") \
        || die '无法连接访问代理配置服务。'
    [ "$status" = '200' ] || {
        message=$(json_string message "$response_file")
        [ -n "$message" ] || message="服务端拒绝请求（HTTP $status）"
        die "$message"
    }

    address=$(json_string address "$response_file")
    port=$(json_number port "$response_file")
    proxy_id=$(json_string id "$response_file")
    flow=$(json_string flow "$response_file")
    server_name=$(json_string server_name "$response_file")
    reality_public_key=$(json_string public_key "$response_file")
    short_id=$(json_string short_id "$response_file")
    fingerprint_mode=$(json_string fingerprint "$response_file")
    response_nonce=$(json_string nonce "$response_file")
    response_expires=$(json_number expires_at "$response_file")
    response_signature=$(json_string signature "$response_file")
    [ -n "$address" ] && [ -n "$port" ] && [ -n "$proxy_id" ] && [ -n "$server_name" ] \
        && [ -n "$reality_public_key" ] && [ -n "$response_signature" ] \
        || die '服务端代理配置不完整。'
    [ "$response_nonce" = "$nonce" ] && [ "$response_expires" = "$expires_at" ] \
        || die '服务端代理配置与本次挑战不匹配。'
    verify_signature "config
$address
$port
$proxy_id
$flow
$server_name
$reality_public_key
$short_id
$fingerprint_mode
$response_nonce
$response_expires" "$response_signature" || die '服务端代理配置签名无效，已拒绝使用。'
}

install_runtime() {
    [ -f "$XRAY_SOURCE" ] || die '安装包中缺少代理核心，请重新下载与本机架构匹配的完整 ZIP。'
    mkdir -p "$RUNTIME_DIR" "$HOME/Library/LaunchAgents"
    cp "$XRAY_SOURCE" "$XRAY_BIN"
    chmod 700 "$XRAY_BIN"
    xattr -d com.apple.quarantine "$XRAY_BIN" 2>/dev/null || true
    cat > "$XRAY_CONFIG" <<EOF
{
  "log": {"loglevel": "warning", "error": "$RUNTIME_DIR/xray-error.log"},
  "inbounds": [{
    "tag": "local-http", "listen": "127.0.0.1", "port": $LOCAL_PROXY_PORT, "protocol": "http",
    "settings": {"allowTransparent": false},
    "sniffing": {"enabled": true, "destOverride": ["http", "tls"], "routeOnly": false}
  }],
  "outbounds": [{
    "tag": "openai-remote", "protocol": "vless",
    "settings": {"vnext": [{"address": "$address", "port": $port, "users": [{"id": "$proxy_id", "encryption": "none", "flow": "$flow"}]}]},
    "streamSettings": {"network": "tcp", "security": "reality", "realitySettings": {
      "serverName": "$server_name", "fingerprint": "$fingerprint_mode", "publicKey": "$reality_public_key", "shortId": "$short_id", "spiderX": "/"
    }}
  }, {"tag": "block", "protocol": "blackhole"}],
  "routing": {"domainStrategy": "AsIs", "rules": [{"type": "field", "inboundTag": ["local-http"], "outboundTag": "openai-remote"}]}
}
EOF
    chmod 600 "$XRAY_CONFIG"
    "$XRAY_BIN" run -test -config "$XRAY_CONFIG" >/dev/null 2>&1 || die '代理核心配置校验失败。'

    cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array><string>$XRAY_BIN</string><string>run</string><string>-config</string><string>$XRAY_CONFIG</string></array>
  <key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$RUNTIME_DIR/xray-stdout.log</string>
  <key>StandardErrorPath</key><string>$RUNTIME_DIR/xray-stderr.log</string>
</dict></plist>
EOF
    chmod 600 "$PLIST"
    launchctl bootout "gui/$(id -u)/$LABEL" >/dev/null 2>&1 || true
    launchctl bootstrap "gui/$(id -u)" "$PLIST" || die '无法启动登录项代理服务。'
    launchctl kickstart -k "gui/$(id -u)/$LABEL" >/dev/null
}

network_services() {
    networksetup -listallnetworkservices | tail -n +2 | sed '/^An asterisk/d; /^$/d'
}

field_value() {
    label=$1
    file=$2
    sed -n "s/^$label: //p" "$file" | head -n 1
}

backup_network_services() {
    [ -f "$STATE_DIR/active" ] && return 0
    rm -rf "$STATE_DIR"
    mkdir -p "$STATE_DIR/services"
    index=0
    network_services | while IFS= read -r service; do
        service_dir="$STATE_DIR/services/$index"
        mkdir -p "$service_dir"
        printf '%s\n' "$service" > "$service_dir/name"
        networksetup -getautoproxyurl "$service" > "$service_dir/auto" 2>/dev/null || { rm -rf "$service_dir"; continue; }
        networksetup -getwebproxy "$service" > "$service_dir/http" 2>/dev/null || true
        networksetup -getsecurewebproxy "$service" > "$service_dir/https" 2>/dev/null || true
        networksetup -getsocksfirewallproxy "$service" > "$service_dir/socks" 2>/dev/null || true
        networksetup -getproxybypassdomains "$service" > "$service_dir/bypass" 2>/dev/null || true
        networksetup -getproxyautodiscovery "$service" > "$service_dir/discovery" 2>/dev/null || true
        index=$((index + 1))
    done
    [ -d "$STATE_DIR/services/0" ] || die '没有找到可配置的 macOS 网络服务。'
}

pac_quote() {
    printf '%s' "$1" | sed "s/\\\\/\\\\\\\\/g; s/'/\\\\'/g"
}

static_fallback() {
    service_dir=$1
    result=''
    if [ -f "$service_dir/bypass" ]; then
        while IFS= read -r bypass; do
            [ -n "$bypass" ] || continue
            if [ "$bypass" = '*.local' ] || [ "$bypass" = '<local>' ]; then
                result="$result if (isPlainHostName(host)) return 'DIRECT';"
            else
                escaped=$(pac_quote "$bypass")
                result="$result if (shExpMatch(host,'$escaped')) return 'DIRECT';"
            fi
        done < "$service_dir/bypass"
    fi
    https_enabled=$(field_value Enabled "$service_dir/https")
    https_server=$(field_value Server "$service_dir/https")
    https_port=$(field_value Port "$service_dir/https")
    http_enabled=$(field_value Enabled "$service_dir/http")
    http_server=$(field_value Server "$service_dir/http")
    http_port=$(field_value Port "$service_dir/http")
    socks_enabled=$(field_value Enabled "$service_dir/socks")
    socks_server=$(field_value Server "$service_dir/socks")
    socks_port=$(field_value Port "$service_dir/socks")
    if [ "$https_enabled" = 'Yes' ] && [ -n "$https_server" ]; then
        result="$result if (url.substring(0,6).toLowerCase()==='https:') return 'PROXY $(pac_quote "$https_server"):$https_port';"
    fi
    if [ "$http_enabled" = 'Yes' ] && [ -n "$http_server" ]; then
        result="$result if (url.substring(0,5).toLowerCase()==='http:') return 'PROXY $(pac_quote "$http_server"):$http_port';"
    fi
    if [ "$socks_enabled" = 'Yes' ] && [ -n "$socks_server" ]; then
        result="$result return 'SOCKS5 $(pac_quote "$socks_server"):$socks_port';"
    elif [ "$https_enabled" = 'Yes' ] && [ -n "$https_server" ]; then
        result="$result return 'PROXY $(pac_quote "$https_server"):$https_port';"
    elif [ "$http_enabled" = 'Yes' ] && [ -n "$http_server" ]; then
        result="$result return 'PROXY $(pac_quote "$http_server"):$http_port';"
    else
        result="$result return 'DIRECT';"
    fi
    printf '%s' "$result"
}

build_pac_for_service() {
    service_dir=$1
    pac_file="$service_dir/proxy.pac"
    auto_enabled=$(field_value Enabled "$service_dir/auto")
    auto_url=$(field_value URL "$service_dir/auto")
    previous_function=''
    fallback=''
    if [ "$auto_enabled" = 'Yes' ] && [ -n "$auto_url" ] && [ "$auto_url" != '(null)' ]; then
        previous="$service_dir/previous.pac"
        case "$auto_url" in
            file://*) cp "${auto_url#file://}" "$previous" 2>/dev/null || die "无法读取 $auto_url；未修改系统代理。" ;;
            *) curl --fail --silent --show-error --connect-timeout 8 --max-time 20 "$auto_url" > "$previous" \
                || die "无法读取原 PAC：$auto_url；未修改系统代理。" ;;
        esac
        grep -Eq 'FindProxyForURL[[:space:]]*\(' "$previous" || die '原 PAC 不包含 FindProxyForURL，无法安全组合。'
        sed 's/FindProxyForURL/__cqsPreviousFindProxyForURL/g' "$previous" > "$service_dir/previous-renamed.pac"
        previous_function=$(cat "$service_dir/previous-renamed.pac")
        fallback='return __cqsPreviousFindProxyForURL(url, host);'
    else
        fallback=$(static_fallback "$service_dir")
    fi
    cat > "$pac_file" <<EOF
var __cqsDomains=['openai.com','chatgpt.com','chat.com','oaistatic.com','oaiusercontent.com','oaistatsig.com','sora.com','crixet.com','challenges.cloudflare.com','production-openaicom-storage.azureedge.net','openaicomproductionae4b.blob.core.windows.net'];
function __cqsOpenAI(host){host=(host||'').toLowerCase().replace(/\\.$/,'');for(var i=0;i<__cqsDomains.length;i++){var d=__cqsDomains[i];if(host===d||dnsDomainIs(host,'.'+d))return true;}return false;}
$previous_function
function FindProxyForURL(url,host){if(__cqsOpenAI(host))return 'PROXY 127.0.0.1:$LOCAL_PROXY_PORT'; $fallback}
EOF
    chmod 600 "$pac_file"
}

apply_proxy_settings() {
    for service_dir in "$STATE_DIR"/services/*; do
        [ -d "$service_dir" ] || continue
        service=$(cat "$service_dir/name")
        build_pac_for_service "$service_dir"
        pac_url="file://$service_dir/proxy.pac"
        networksetup -setautoproxyurl "$service" "$pac_url" >/dev/null \
            || die "无法为网络服务 $service 设置自动代理。"
        networksetup -setautoproxystate "$service" on >/dev/null \
            || die "无法启用网络服务 $service 的自动代理。"
        networksetup -setproxyautodiscovery "$service" off >/dev/null 2>&1 || true
    done
    : > "$STATE_DIR/active"
}

restore_proxy_settings() {
    [ -d "$STATE_DIR/services" ] || return 0
    for service_dir in "$STATE_DIR"/services/*; do
        [ -d "$service_dir" ] || continue
        service=$(cat "$service_dir/name")
        old_enabled=$(field_value Enabled "$service_dir/auto")
        old_url=$(field_value URL "$service_dir/auto")
        if [ -n "$old_url" ] && [ "$old_url" != '(null)' ]; then
            networksetup -setautoproxyurl "$service" "$old_url" >/dev/null 2>&1 || true
        fi
        if [ "$old_enabled" = 'Yes' ]; then
            networksetup -setautoproxystate "$service" on >/dev/null 2>&1 || true
        else
            networksetup -setautoproxystate "$service" off >/dev/null 2>&1 || true
        fi
        discovery_enabled=$(field_value Enabled "$service_dir/discovery")
        if [ "$discovery_enabled" = 'Yes' ]; then
            networksetup -setproxyautodiscovery "$service" on >/dev/null 2>&1 || true
        else
            networksetup -setproxyautodiscovery "$service" off >/dev/null 2>&1 || true
        fi
    done
}

proxy_on() {
    require_command networksetup
    require_command launchctl
    request_endpoint
    backup_network_services
    proxy_on_committed=0
    trap '
        if [ "${proxy_on_committed:-0}" != "1" ]; then
            restore_proxy_settings
            launchctl bootout "gui/$(id -u)/$LABEL" >/dev/null 2>&1 || true
            rm -f "$PLIST"
            rm -rf "$STATE_DIR"
            printf "开启失败，已恢复原自动代理设置。\n" >&2
        fi
    ' 0 1 2 15
    install_runtime
    apply_proxy_settings
    proxy_on_committed=1
    trap - 0 1 2 15
    printf '访问代理已开启。仅 OpenAI/ChatGPT 官方域名使用内置代理，其他流量沿用原代理设置。\n'
}

proxy_off() {
    restore_proxy_settings
    launchctl bootout "gui/$(id -u)/$LABEL" >/dev/null 2>&1 || true
    rm -f "$PLIST"
    rm -rf "$STATE_DIR"
    printf '访问代理已关闭，原自动代理设置已恢复。\n'
}

proxy_status() {
    if [ -f "$STATE_DIR/active" ] && launchctl print "gui/$(id -u)/$LABEL" >/dev/null 2>&1; then
        printf '访问代理：已开启\n'
        exit 0
    fi
    if [ -f "$STATE_DIR/active" ]; then
        printf '访问代理：配置存在，但后台服务未运行。请重新执行 proxy-on 或先执行 proxy-off。\n'
        exit 1
    fi
    printf '访问代理：未开启\n'
}

case "${1:-}" in
    on) proxy_on ;;
    off) proxy_off ;;
    status) proxy_status ;;
    *) printf '用法：%s on|off|status\n' "$0" >&2; exit 2 ;;
esac
